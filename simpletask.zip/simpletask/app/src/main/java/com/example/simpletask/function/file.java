package com.example.simpletask.function;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class file {
    public boolean fileExists(Context context, String filename) {
        File file = context.getFileStreamPath(filename);
        if (file == null || !file.exists()) {
            return false;
        }
        return true;
    }
    /**
     * 所有的数据都读取
     *
     * @return*/
    public String readfile(Context context, String filename) {
        String readed = null;
        try {
            //将文件读取到String中
            FileInputStream fis = context.openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis, "utf-8");
            char[] input = new char[fis.available()];
            isr.read(input);
            isr.close();
            fis.close();
            readed= String.valueOf(input);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return readed;
    }
    /**
     * 所有的数据都写入
     * */
    public void savefile(Context context, String filename, String inp) {
        try {
            //将文件数据写入到应用的内部
            FileOutputStream fos = context.openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "utf-8");
            osw.write(inp);
            osw.flush();
            fos.flush();
            osw.close();
            fos.close();
            //Toast.makeText(this,"写入完成",Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return;
    }
}
