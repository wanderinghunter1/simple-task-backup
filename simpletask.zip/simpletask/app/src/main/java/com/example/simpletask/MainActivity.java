package com.example.simpletask;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.simpletask.function.file;
import com.example.simpletask.function.getTime;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    private String dateshow="";
    private file usefile=new file();
    private getTime usetime=new getTime();
    private int slide=0;
    private String user="simple";

    private int textsize=20;
    private int linesize=100;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        settime();
        create();
    }
    @SuppressLint("ResourceAsColor")
    protected void create()
    {
        change();
        int completed=0;
        LinearLayout linearLayout=findViewById(R.id.LinearTest);
        linearLayout.removeAllViews();
        /***
         * 动态删除所有的内容，直接删除然后重新添加
         */

        if(user.equals("voice"))
        {
            Button btnLesson =new Button(this);
            btnLesson.setText("语音使用任务");
            btnLesson.setTextSize(40);
            btnLesson.setHeight(400);
            //btnLesson.setSingleLine(false);
            btnLesson.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    voiceuse();
                }
            });
            linearLayout.addView(btnLesson);
        }
        if(!usefile.fileExists(this,dateshow))
        {
            return ;
        }
        int sum= Integer.parseInt(usefile.readfile(this,dateshow));
        for(int i=0; i<sum;i++)
        {
            String filename=dateshow+i+'b';
            System.out.println(usefile.readfile(this,filename));
            if(usefile.readfile(this,filename).equals("yes"))
            {
                continue;
            }
            TextView text=new TextView(this);
            text.setText(usefile.readfile(this,dateshow+i));
            text.setTextColor(Color.BLACK);
            text.setId(i);
            text.setHeight(linesize);
            text.setTextSize(textsize);

            text.setSingleLine(false);
            linearLayout.addView(text);



            Button btnLesson =new Button(this);
            btnLesson.setText("完成了上述任务");
            if(user.equals("young"))
            {
                btnLesson.setText("zuo wan le");
            }
            btnLesson.setTextSize(textsize);
            btnLesson.setHeight(linesize);
            //btnLesson.setSingleLine(false);
            btnLesson.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    try {
                        //将文件数据写入到应用的内部
                        FileOutputStream fos = openFileOutput(filename, MODE_PRIVATE);
                        OutputStreamWriter osw = new OutputStreamWriter(fos, "utf-8");
                        osw.write("yes");
                        osw.flush();
                        fos.flush();
                        osw.close();
                        fos.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //System.out.println("更新为 ------- yes");
                    String readed = null;
                    try {
                        //将文件读取到String中
                        FileInputStream fis = openFileInput(filename);
                        InputStreamReader isr = new InputStreamReader(fis, "utf-8");
                        char[] input = new char[fis.available()];
                        isr.read(input);
                        isr.close();
                        fis.close();
                        readed= String.valueOf(input);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    System.out.println(readed);
                    create();
                    //flush();
                }
            });
            linearLayout.addView(btnLesson);
        }
        for(int i=0; i<sum;i++)
        {
            String filename=dateshow+i+'b';
            System.out.println(usefile.readfile(this,filename));
            if(usefile.readfile(this,filename).equals("no"))
            {
                continue;
            }
            completed+=1;
            TextView text=new TextView(this);
            text.setText(usefile.readfile(this,dateshow+i));
            text.setTextColor(Color.BLACK);
            text.setId(i);
            text.setHeight(linesize);
            text.setTextSize(textsize);

            text.setSingleLine(false);
            text.setBackgroundColor(Color.GRAY);
            linearLayout.addView(text);


            Button btnLesson =new Button(this);
            btnLesson.setText("重新启用任务");
            if(user.equals("young"))
            {
                btnLesson.setText("mei zuo wan");
            }
            btnLesson.setTextSize(textsize);
            btnLesson.setHeight(linesize);
            //btnLesson.setSingleLine(false);
            btnLesson.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                try {
                    //将文件数据写入到应用的内部
                    FileOutputStream fos = openFileOutput(filename, MODE_PRIVATE);
                    OutputStreamWriter osw = new OutputStreamWriter(fos, "utf-8");
                    osw.write("no");
                    osw.flush();
                    fos.flush();
                    osw.close();
                    fos.close();
                    System.out.println("更新为 ------- no");
                    String readed = null;
                    try {
                        //将文件读取到String中
                        FileInputStream fis = openFileInput(filename);
                        InputStreamReader isr = new InputStreamReader(fis, "utf-8");
                        char[] input = new char[fis.available()];
                        isr.read(input);
                        isr.close();
                        fis.close();
                        readed= String.valueOf(input);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    System.out.println(readed);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                create();
                //flush();
            }
            });
            linearLayout.addView(btnLesson);
        }
        ProgressBar loadingbar=findViewById(R.id.rate);
        TextView finishrate=findViewById(R.id.finishrate);
        completed*=100;
        completed/=sum;
        loadingbar.setProgress(completed);
        String contain= (String) finishrate.getText();
        finishrate.setText("任务完成度："+completed+"%");
        if(user.equals("young"))
        {
            finishrate.setText("zuo wan le "+completed+"%");
        }
    }



    public void change()
    {
        if(!usefile.fileExists(this,"user"))
        {
            usefile.savefile(this,"user","simple");
            return ;
        }
        user=usefile.readfile(this,"user");
        if(user.equals("older"))
        {
            textsize=65;
            linesize=800;
        }
        else
        {
            textsize=20;
            linesize=20;
        }

        if(user.equals("young"))
        {
            Button button=findViewById(R.id.nextday);
            button.setText("ming tian");

            button=findViewById(R.id.lastday);
            button.setText("zuo tian");

            button=findViewById(R.id.newtask);
            button.setText("xin de");

            button=findViewById(R.id.set);
            button.setText("gai dong");

            TextView text=findViewById(R.id.finishrate);
            text.setText("zuo wan le :");

            text=findViewById(R.id.datetextView);
            text.setText("ri qi :");
            return ;
        }
    }

    public void settime()
    {
        /**
         * 初始化时间，找找看
         * */
        if(dateshow=="")//没有设置时间呢,设置一个
        {
            dateshow="当前的日期为："+usetime.alltime(0);
            TextView dateview=findViewById(R.id.datetextView);
            dateview.setText(dateshow);
        }
        create();
    }



    public void onClick(View v){
        /***
         * 跳转页面到 设置
         */
        //监听按钮，如果点击，就跳转
        Intent intent = new Intent();
        //前一个（MainActivity.this）是目前页面，后面一个是要跳转的下一个页面
        intent.setClass(MainActivity.this,SettingActivity.class);
        startActivity(intent);
    }




    public void inputbox(View v)
    {
        /***
         * 新建新的任务
         */
        //获取输入值
        final EditText editText = new EditText(MainActivity.this);
        editText.setSingleLine();
        editText.setHint("点我修改任务");
        editText.requestFocus();
        editText.setFocusable(true);
        AlertDialog.Builder inputDialog = new AlertDialog.Builder(this)
                .setTitle("新的任务")
                .setView(editText).setPositiveButton("确定", (dialog, which) -> {
                    String inputstring=editText.getText().toString();
                    //text.setText(content);
                    // TODO 确定的操作
                    insertnewtask(inputstring);
                }).setNegativeButton("取消", (dialogInterface, i) -> dialogInterface.dismiss());
        inputDialog.create().show();
    }






    public DialogInterface.OnClickListener insertnewtask(String inp)
    {
        if(!usefile.fileExists(this,dateshow))//什么都没有
        {
            //Toast.makeText(this,"不存在", Toast.LENGTH_SHORT).show();
            usefile.savefile(this,dateshow,"1");
            usefile.savefile(this,dateshow+'0',inp);
            usefile.savefile(this,dateshow+"0b", "no");
        }
        else//存在一点数据
        {
            int now= Integer.parseInt(usefile.readfile(this,dateshow));
            usefile.savefile(this,dateshow+now,inp);
            usefile.savefile(this,dateshow+now+'b',"no" );
            now+=1;
            usefile.savefile(this,dateshow, String.valueOf(now));
        }
        create();
        return null;
    }




    public void nextday(View v)
    {/***
     * 跳转到下一天
     */
        dateshow="当前的日期为："+usetime.alltime(1+slide);
        slide+=1;
        TextView dateview=findViewById(R.id.datetextView);
        dateview.setText(dateshow);
        create();
    }




    public void lastday(View v)
    {/***
     * 跳转到上一天
     */
        dateshow="当前的日期为："+usetime.alltime(-1+slide);
        slide-=1;
        TextView dateview=findViewById(R.id.datetextView);
        dateview.setText(dateshow);
        create();
    }




    public void directday(View v)//直接跳转到另一天
    {/***
     * 跳转到特定的一天
     */
        //获取输入值
        final EditText editText = new EditText(MainActivity.this);
        editText.setSingleLine();
        editText.setHint("日期格式为：yyyy-mm-dd");
        editText.requestFocus();
        editText.setFocusable(true);
        AlertDialog.Builder inputDialog = new AlertDialog.Builder(this)
                .setTitle("新的日期")
                .setView(editText).setPositiveButton("确定", (dialog, which) -> {
                    String inputstring=editText.getText().toString();
                    //text.setText(content);
                    // TODO 确定的操作
                    changedate(inputstring);
                }).setNegativeButton("取消", (dialogInterface, i) -> dialogInterface.dismiss());
        inputDialog.create().show();
    }




    public DialogInterface.OnClickListener changedate(String inp)//修改日期
    {
        if (inp.length()!=10)
        {
            return null;
        }
        dateshow="当前的日期为："+inp;
        //Toast.makeText(this,inp, Toast.LENGTH_SHORT).show();
        slide=0;
        TextView dateview=findViewById(R.id.datetextView);
        dateview.setText(dateshow);
        create();
        return null;
    }



    public void flush() {
        finish();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void voiceuse()
    {
        final EditText editText = new EditText(MainActivity.this);
        editText.setSingleLine();
        editText.setHint("说出您的操作");
        editText.requestFocus();
        editText.setFocusable(true);
        AlertDialog.Builder inputDialog = new AlertDialog.Builder(this)
                .setTitle("例如：”添加任务“”喝水“")
                .setView(editText).setPositiveButton("确定", (dialog, which) -> {
                    String inputstring=editText.getText().toString();
                    //text.setText(content);
                    // TODO 确定的操作
                    boolean status = inputstring.contains("insert");
                    if(status)
                    {
                        inputstring=inputstring.replace("insert","");
                        System.out.println("插入可行");
                        insertnewtask(inputstring);
                    }
                    status = inputstring.contains("insert");
                    if(status)
                    {
                        inputstring=inputstring.replace("insert","");
                        System.out.println("插入可行");
                        insertnewtask(inputstring);
                    }
                }).setNegativeButton("取消", (dialogInterface, i) -> dialogInterface.dismiss());
        inputDialog.create().show();
        return;
    }
}