package com.example.simpletask.function;

public class getColor {
    
}
